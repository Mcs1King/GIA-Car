
<body>
<div class="foot-top">	
</div>

<div class="footer">
	<div class="container">
		<div class="col-md-3 cust">
			<h4>Kundenservice</h4>
				<li><a href="#">Hilfe</a></li>
				<li><a href="#">FAQ</a></li>
				<li><a href="contact.php">Kontakt</a></li>
		</div>
		<div class="col-md-2 abt">
			<h4>Über uns</h4>
				<li><a href="#">Neuigkeiten</a></li>
				<li><a href="#">Karriere</a></li>
		</div>
		<div class="col-md-2 myac">
			<h4>Account</h4>
				<li><a href="register.php">Registrieren</a></li>
				<li><a href="checkout.php">Watchlist</a></li>
		</div>
		<div class="col-md-5 our-st">
			<div class="our-left">
				<h4>GIA-CAR</h4>
			</div>
			
			<div class="clearfix"> </div>
				<li><i class="add"> </i>Hoffschultestraße 25, 48155 Münster</li>
				<li><i class="phone"> </i>0251/8987683</li>
				<li><a href="mailto:info@example.com"><i class="mail"> </i>info@giacar.de </a></li>
			
		</div>
		<div class="clearfix"> </div>
			<p>Copyrights © 2017 GIA-CAR. All rights reserved to GIA-CAR</p>
	</div>
</div>
</body>
</html>