<?php
         include('header.php');
?>
<!-- content -->
<div class="container">
<div class="women_main">
	<!-- start sidebar -->
	<div class="col-md-3 s-d">
	  <div class="w_sidebar">
		<div class="w_nav1">
			<h4>Suchen</h4>
			<ul>
				<li><a href="#"></a></li>
			</ul>	
		</div>
		<h3>Filter</h3>
		
		<section  class="sky-form">
					<h4>Alle Klassen</h4>
						<div class="row1 scroll-pane">
							<div class="col col-4">
								<label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>A</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>B</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>C</label>
							</div>
							<div class="col col-4">
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>CLA</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>CLS</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>E</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>G</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>GLA</label>
								<label class="checkbox"><input type="checkbox" name="checkbox" ><i></i>GLC</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>GLE</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>GLS</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>S</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>SLC</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>V</label>	
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>AMG GT</label>																								
								
							</div>
						</div>
		</section>
		<section  class="sky-form">
					<h4>Ausstattung</h4>
						<div class="row1 scroll-pane">
							<div class="col col-4">
								<label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Radio</label>
							</div>
							<div class="col col-4">
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>ESP</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i> Airbag</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Klimaanlage</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i> Freisprechanlage</label>
								<label class="checkbox"><input type="checkbox" name="checkbox" ><i></i>elektrische Außenspiegel</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>eletktrische Fenster</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Navigation</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Tempomat</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Armlehne</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Lenkradheizung</label>
								<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>Dach</label>
							
							</div>
						</div>
		</section>
		<section class="sky-form">
			<h4>Farbe</h4>
			<ul class="w_nav2">
				<li><a class="color1" href="#"></a></li>
				<li><a class="color2" href="#"></a></li>
				<li><a class="color3" href="#"></a></li>
			<!--<li><a class="color1" href="#"></a></li>
				<li><a class="color2" href="#"></a></li>
				<li><a class="color3" href="#"></a></li>
				<li><a class="color4" href="#"></a></li>
				<li><a class="color5" href="#"></a></li>
				<li><a class="color6" href="#"></a></li>
				<li><a class="color7" href="#"></a></li>
				<li><a class="color8" href="#"></a></li>
				<li><a class="color9" href="#"></a></li>
				<li><a class="color10" href="#"></a></li>
				<li><a class="color12" href="#"></a></li>
				<li><a class="color13" href="#"></a></li>
				<li><a class="color14" href="#"></a></li>
				<li><a class="color15" href="#"></a></li>
				<li><a class="color5" href="#"></a></li>
				<li><a class="color6" href="#"></a></li>
				<li><a class="color7" href="#"></a></li>
				<li><a class="color8" href="#"></a></li>
				<li><a class="color9" href="#"></a></li>
				<li><a class="color10" href="#"></a></li> -->
			</ul>
		</section>
		<!--<section class="sky-form">
						<h4>Rabatte</h4>
						<div class="row1 scroll-pane">
							<div class="col col-4">
								<label class="radio"><input type="radio" name="radio" checked=""><i></i>60 % and above</label>
								<label class="radio"><input type="radio" name="radio"><i></i>50 % and above</label>
								<label class="radio"><input type="radio" name="radio"><i></i>40 % and above</label>
							</div>
							<div class="col col-4">
								<label class="radio"><input type="radio" name="radio"><i></i>30 % and above</label>
								<label class="radio"><input type="radio" name="radio"><i></i>20 % and above</label>
								<label class="radio"><input type="radio" name="radio"><i></i>10 % and above</label>
							</div>
						</div>						
		</section>-->
	</div>
   </div>
	<!-- start content -->
	<div class="col-md-9 w_content">
		<div class="women">
			<a href="#"><h4>Autos <span>4449 items</span> </h4></a>
			<ul class="w_nav">
						<li>Sortieren nach : </li>
		     			<li><a class="active" href="#">Beliebheit</a></li> |
		     			<li><a href="#">Neu </a></li> |
		     			<li><a href="#">Rabatte</a></li> |
		     			<li><a href="#">Preis </a></li> 
		     			<div class="clear"></div>	
		     </ul>
		     <div class="clearfix"></div>	
		</div>
		<!-- grids_of_4 -->
		<div class="grids_of_4">
		  <div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/a.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> A-Klasse</a></h4>
				     <p>A-Klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $99.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/B.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> B-klasse </a></h4>
				     <p>b klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $76.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">Watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/c.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> C klasse</a></h4>
				     <p>C- klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $58.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/cla.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> Cla-klasse</a></h4>
				     <p>Cla- klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $112.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="clearfix"></div>
		</div>
		
		
		<div class="grids_of_4">
		 <div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/cls.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> cls-klasse</a></h4>
				     <p>cls-klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $109.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/e.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> E-klasse</a></h4>
				     <p>E-klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $95.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/g.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> g-klasse</a></h4>
				     <p>G-klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $68.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/gla.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> GLA-Klasse</a></h4>
				     <p>GLA_klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $74.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="grids_of_4">
		  <div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/glc.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> GLC-Klasse</a></h4>
				     <p>GLC-Klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $80.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/Gls.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> GLs-Klasse</a></h4>
				     <p>GLs-Klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $65.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/s.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> S-Klasse</a></h4>
				     <p>S-Klasse</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $90.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="grid1_of_4">
				<div class="content_box"><a href="details.php">
			   	   	 <img src="images/amg.jpg" class="img-responsive" alt=""/>
				   	  </a>
				    <h4><a href="details.php"> AMG</a></h4>
				     <p>AMG</p>
					 <div class="grid_1 simpleCart_shelfItem">
				    
					 <div class="item_add"><span class="item_price"><h6>ONLY $75.00</h6></span></div>
					<div class="item_add"><span class="item_price"><a href="#">watchlist</a></span></div>
					 </div>
			   	</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- end grids_of_4 -->
		
		
	</div>
	<div class="clearfix"></div>
	
	<!-- end content -->
</div>
</div>
<?php
     include('footer.php');
?>