<!DOCTYPE HTML>
<html>
<head>
<title>Gia-Car</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary JavaScript plugins) -->
<script type='text/javascript' src="js/jquery-1.11.1.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
<!-- start menu -->
<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/etalage.css">
<script type="text/javascript" src="js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<script src="js/jquery.etalage.min.js"></script>
<script src="js/menu_jquery.js"></script>
<script>
			jQuery(document).ready(function($){

				$('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 900,
					source_image_height: 1200,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>

</head>
<body>
<!-- header_top -->
<div class="top_bg">
	<div class="container">
		<div class="header_top">
			<div class="top_right">
				<ul>
					<li><a href="#">Hilfe</a></li>|
					<li><a href="contact.php">Kontakt</a></li>|
					<li><a href="#">Impressum</a></li>
				</ul>
			</div>
			<div class="top_left">
				<h2><span></span> Telefon: 0251/8987683</h2>
			</div>
				<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!-- header -->
<div class="header_bg">
<div class="container">
	<div class="header">
	<div class="head-t">
		<div class="logo">
			<a href="index.php"><img src="images/logo.svg" width="256px" class="img-responsive" alt=""/> </a>
		</div>
		<!-- start header_right -->
		<div class="header_right">
			<div class="rgt-bottom">
				<div class="log">
					<div class="login" >
						<div id="loginContainer"><a href="#" id="loginButton"><span>Login</span></a>
						    <div id="loginBox">                
						        <form id="loginForm">
						                <fieldset id="body">
						                	<fieldset>
						                          <label for="email">Email Addresse</label>
						                          <input type="text" name="email" id="email">
						                    </fieldset>
						                    <fieldset>
						                            <label for="password">Passwort</label>
						                            <input type="password" name="password" id="password">
						                     </fieldset>
						                    <input type="submit" id="login" value="Sign in">
						                	<label for="checkbox"><input type="checkbox" id="checkbox"> <i>Login merken</i></label>
						            	</fieldset>
						            <span><a href="#">Passwort vergessen?</a></span>
								</form>
							</div>
						</div>
					</div>
				</div>
				<div class="reg">
					<a href="register.php">Registrieren</a>
				</div>
			<div class="cart box_1">
				<a href="checkout.php">
					<h3> <span class="simpleCart_total">$0.00</span> (<span id="simpleCart_quantity" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt=""></h3>
				</a>	
				<p><a href="javascript:;" class="simpleCart_empty">(empty card)</a></p>
				<div class="clearfix"> </div>
			</div>
			<div class="create_btn">
				<a href="checkout.php">Check</a>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="search">
		    <form>
		    	<input type="text" value="" placeholder="search...">
				<input type="submit" value="">
			</form>
		</div>
		<div class="clearfix"> </div>
		</div>
		<div class="clearfix"> </div>
	</div>
		<!-- start header menu -->
		<ul class="megamenu skyblue">
			<li class="active grid"><a class="color1" href="index.php">Startseite</a></li>
			<li class="grid"><a class="color2" href="#">Highlights</a>
				<div class="megapanel">
					<div class="row">					
						<div class="col1">
							<div class="h_nav">
								<h4>Mercedes-Benz</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>

								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Audi</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Porsche</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>						
						</div>					
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
			<li><a class="color4" href="#">Alle Marken</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>Mercedes-Benz</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Audi</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Porsche</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Skoda</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>SEAT</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Volkswagen</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>				
				<li><a class="color5" href="#">Motorräder</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>Suzuki</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Honda</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Yamaha</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>BMW</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Vespa/Piaggo</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Ducati</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
				<li><a class="color6" href="#">Lastkraftwagen</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>Mercedes-Benz</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>MAN</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Iveco</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>												
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Scania</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>						
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Volvo</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Renault</h4>
								<ul>
									<li><a href="filter.php">Diesel</a></li>
									<li><a href="filter.php">Benzin</a></li>
									<li><a href="filter.php">Elektro</a></li>
									<li><a href="filter.php">Gas</a></li>
									<li><a href="filter.php">Wasser</a></li>
									<li><a href="filter.php">Hybrid</a></li>
								</ul>	
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>				
			
				<li><a class="color7" href="#">Account</a>
				<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								<h4>Benutzername</h4>
								<ul>
									<li><a href="#">login</a></li>
									<li><a href="register.php">create an account</a></li>
									<li><a href="filter.php">create wishlist</a></li>
									<li><a href="checkout.php">Checkout</a></li>
								</ul>	
							</div>						
						</div>
					</div>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>				
					<li class="active grid"><a class="color1" href="contact.php">Kontakt</a></li>
					<div class="row">
						<div class="col2"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
						<div class="col1"></div>
					</div>
    				</div>
				</li>
				
		 </ul> 
	</div>
</div>
</div>
</body>
</html>