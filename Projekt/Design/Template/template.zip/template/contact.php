
<?php
     include('header.php');
?>
<!-- content -->
<div class="container">
<div class="main">
<div class="contact">				
					<div class="contact_info">
						<h2>Karte</h2>
			    	 		<div class="map">
					   			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d78683.81358527149!2d7.6019521!3d51.9545771!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47b9bb3b2c7927d9%3A0x1aeb26b29cb8c765!2sHans-B%C3%B6ckler-Berufskolleg!5e0!3m2!1sde!2sde!4v1485370620498" width="100%" height="250" frameborder="0" style="border:0"></iframe>
					   		</div>
      				</div>
				  <div class="contact-form">
			 	  	 	<h2>Kontaktieren Sie uns</h2>
			 	 	    <form method="post" action="contact-post.html">
					    	<div>
						    	<span><label>Name</label></span>
						    	<span><input name="userName" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>E-mail</label></span>
						    	<span><input name="userEmail" type="text" class="textbox"></span>
						    </div>
						    <div>
						     	<span><label>Telefon</label></span>
						    	<span><input name="userPhone" type="text" class="textbox"></span>
						    </div>
						    <div>
						    	<span><label>Betreff</label></span>
						    	<span><textarea name="userMsg"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" class="" value="Abschicken"></span>
						  </div>
					    </form>
				    </div>
  				<div class="clearfix"></div>		
			  </div>
</div>
</div>
<?php
     include('footer.php');
?>