
<?php
     include('header.php');
?>
<div class="container">
	<div class="check">	 
			 <div class="col-md-3 cart-total">
			 <a class="continue" href="#">Warenkorb</a>
			 <div class="price-details">
				 <h3>Details</h3>
				 <span>Preis</span>
				 <span class="total1">Variable</span>
				 <span>Lieferungskosten</span>
				 <span class="total1">-</span>
				 <div class="clearfix"></div>				 
			 </div>	
			 <ul class="total_price">
			   <li class="last_price"> <h4>Summe</h4></li>	
			   <li class="last_price"><span>SumVariable</span></li>
			   <div class="clearfix"> </div>
			 </ul>
			
			 
			 <div class="clearfix"></div>
			 <a class="order" href="#">Kaufen</a>
			</div>
		 <div class="col-md-9 cart-items">
			 <h1>Watchlist (2)</h1>
				<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cart-header').fadeOut('slow', function(c){
							$('.cart-header').remove();
						});
						});	  
					});
			   </script>
			 <div class="cart-header">
				 <div class="close1"> </div>
				 <div class="cart-sec simpleCart_shelfItem">
						<div class="cart-item cyc">
							 <img src="images/r8.jpg" class="img-responsive" alt=""/>
						</div>
					   <div class="cart-item-info">
						<h3><a href="#">Audi R8</a><span>Model No: XXXX</span></h3>
						<ul class="qty">
							<li><p>Farbe weiß</p></li>
							<li><p>Dieselmotor</p></li>
						</ul>
						
							 <div class="delivery">
							 
							 <p>Lierferung innerhalb 2-3 Tagen</p>
							 <div class="clearfix"></div>
				        </div>	
					   </div>
					   <div class="clearfix"></div>
											
				  </div>
			 </div>
			 <script>$(document).ready(function(c) {
					$('.close2').on('click', function(c){
							$('.cart-header2').fadeOut('slow', function(c){
						$('.cart-header2').remove();
					});
					});	  
					});
			 </script>
			 <div class="cart-header2">
				 <div class="close2"> </div>
				  <div class="cart-sec simpleCart_shelfItem">
						<div class="cart-item cyc">
							 <img src="images/bmw5.jpg" class="img-responsive" alt=""/>
						</div>
					   <div class="cart-item-info">
						<h3><a href="#">BMW 5er</a><span>Model No: XXXX</span></h3>
						<ul class="qty">
							<li><p>Farbe : Rot</p></li>
							<li><p>Benzinmotor</p></li>
						</ul>
							 <div class="delivery">
							 	<p>Lierferung innerhalb 2-3 Tagen</p>
							 <div class="clearfix"></div>
				        </div>	
					   </div>
					   <div class="clearfix"></div>
											
				  </div>
			  </div>		
		 </div>
		 
		
			<div class="clearfix"> </div>
	 </div>
	 </div>
<?php
     include('footer.php');
?>